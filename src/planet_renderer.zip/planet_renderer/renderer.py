"""固定 Patch Slot、GPU 程序地形生成与 Taichi 分块光栅化。"""
import math,time
from dataclasses import dataclass
import numpy as np
import taichi as ti
from .camera import PlanetCamera
from .height import HeightProvider
from .lighting import LightingState
from .planet import PlanetModel
from .postprocess import display_transform
from .terrain_lod import cube_face_direction
from .terrain_types import PatchDescriptor,PatchKey

TILE_SIZE=16; MAX_TRIANGLES_PER_TILE=512

@dataclass(frozen=True)
class TimingResult: jit_seconds:float; average_seconds:float; frames_per_second:float
@dataclass(frozen=True)
class RasterStats: patches:int; vertices:int; triangles:int; tile_overflow:int

def create_cube_sphere(n:int)->tuple[np.ndarray,np.ndarray]:
    if n<2:raise ValueError("立方体球细分必须至少为 2")
    vertices=[];triangles=[];side=n+1
    for face in range(6):
        base=len(vertices)
        for y in range(side):
            for x in range(side):vertices.append(cube_face_direction(face,x/n*2-1,y/n*2-1))
        for y in range(n):
            for x in range(n):
                a=base+y*side+x;b=a+1;c=a+side;d=c+1;triangles.extend(((a,b,c),(b,d,c)))
    return np.asarray(vertices,np.float32),np.asarray(triangles,np.int32)

def _shared_topology(n:int)->np.ndarray:
    side=n+1;tri=[]
    for y in range(n):
        for x in range(n):
            a=y*side+x;b=a+1;c=a+side;d=c+1;tri.extend(((a,b,c),(b,d,c)))
    edges=(tuple(range(side)),tuple(y*side+n for y in range(side)),tuple(range(n*side,n*side+side))[::-1],tuple(y*side for y in range(side))[::-1])
    base=side*side
    for edge in edges:
        for i in range(n):
            a,b,c,d=edge[i],edge[i+1],base+i,base+i+1;tri.extend(((a,b,c),(b,d,c)))
        base+=side
    return np.asarray(tri,np.int32)

@ti.data_oriented
class PlanetRenderer:
    def __init__(self,width:int,height:int,max_patches:int=256,patch_resolution:int=12,height_provider:HeightProvider|None=None):
        self.width,self.height=width,height;self.max_patches=max_patches;self.resolution=patch_resolution
        self.side=patch_resolution+1;self.surface_vertices=self.side*self.side;self.vertices_per_patch=self.surface_vertices+4*self.side
        topology=_shared_topology(patch_resolution);self.local_triangle_count=len(topology);self.surface_triangle_count=patch_resolution*patch_resolution*2
        self.tiles_x=(width+15)//16;self.tiles_y=(height+15)//16;self.patch_count=0;self.debug_view=0
        seed,continent,mountain=(height_provider.gpu_parameters() if height_provider else (7,2800.,4200.));self.seed=seed;self.continent_amplitude=continent;self.mountain_amplitude=mountain
        self.local_triangles=ti.Vector.field(3,ti.i32,shape=self.local_triangle_count);self.local_triangles.from_numpy(topology)
        self.slot_resident=ti.field(ti.i32,shape=max_patches);self.slot_render=ti.field(ti.i32,shape=max_patches);self.slot_face=ti.field(ti.i32,shape=max_patches);self.slot_level=ti.field(ti.i32,shape=max_patches);self.slot_x=ti.field(ti.i32,shape=max_patches);self.slot_y=ti.field(ti.i32,shape=max_patches);self.slot_skirt_mask=ti.field(ti.i32,shape=max_patches)
        self.anchor_relative=ti.Vector.field(3,ti.f32,shape=max_patches);self.offset=ti.Vector.field(3,ti.f32,shape=(max_patches,self.vertices_per_patch));self.normal=ti.Vector.field(3,ti.f32,shape=(max_patches,self.vertices_per_patch));self.height_m=ti.field(ti.f32,shape=(max_patches,self.vertices_per_patch));self.material=ti.Vector.field(4,ti.f32,shape=(max_patches,self.vertices_per_patch));self.cell=ti.field(ti.i32,shape=(max_patches,self.vertices_per_patch));self.view=ti.Vector.field(3,ti.f32,shape=(max_patches,self.vertices_per_patch))
        raster_capacity=max_patches*self.local_triangle_count*2;rs=(raster_capacity,3)
        self.rv=ti.Vector.field(3,ti.f32,shape=rs);self.rn=ti.Vector.field(3,ti.f32,shape=rs);self.rm=ti.Vector.field(4,ti.f32,shape=rs);self.rh=ti.field(ti.f32,shape=rs);self.rc=ti.field(ti.i32,shape=rs);self.screen=ti.Vector.field(3,ti.f32,shape=rs);self.source=ti.field(ti.i32,shape=raster_capacity);self.valid=ti.field(ti.i32,shape=raster_capacity)
        self.tile_counts=ti.field(ti.i32,shape=(self.tiles_x,self.tiles_y));self.tile_triangles=ti.field(ti.i32,shape=(self.tiles_x,self.tiles_y,MAX_TRIANGLES_PER_TILE));self.tile_overflow=ti.field(ti.i32,shape=())
        shape=(width,height);self.depth=ti.field(ti.f32,shape=shape);self.gbuffer_position=ti.Vector.field(3,ti.f32,shape=shape);self.gbuffer_normal=ti.Vector.field(3,ti.f32,shape=shape);self.gbuffer_albedo=ti.Vector.field(3,ti.f32,shape=shape);self.gbuffer_material_weights=ti.Vector.field(4,ti.f32,shape=shape);self.gbuffer_height_m=ti.field(ti.f32,shape=shape);self.gbuffer_surface_id=ti.field(ti.i32,shape=shape);self.gbuffer_surface_cell_id=ti.field(ti.i32,shape=shape);self.hdr=ti.Vector.field(3,ti.f32,shape=shape);self.display=ti.Vector.field(3,ti.f32,shape=shape)
        self._render_descriptors:tuple[PatchDescriptor,...]=();self._render_slots:dict[PatchKey,int]={}

    @ti.func
    def _hash3(self,x:ti.i32,y:ti.i32,z:ti.i32,seed:ti.i32)->ti.f32:
        value=ti.cast(x,ti.u32)*ti.u32(0x1F123BB5)^ti.cast(y,ti.u32)*ti.u32(0x05491333)^ti.cast(z,ti.u32)*ti.u32(0x72E12A4D)^ti.cast(seed,ti.u32)
        value=(value^(value>>15))*ti.u32(0x2C1B3C6D);value=(value^(value>>12))*ti.u32(0x297A2D39);value=value^(value>>15)
        return ti.cast(value,ti.f32)/4294967295.0
    @ti.func
    def _noise(self,p:ti.template(),seed:ti.i32)->ti.f32:
        base=ti.cast(ti.floor(p),ti.i32);f=p-ti.cast(base,ti.f32);w=f*f*(3.-2.*f);value=0.
        for dz,dy,dx in ti.static(ti.ndrange(2,2,2)):
            value+=self._hash3(base.x+dx,base.y+dy,base.z+dz,seed)*(w.x if dx else 1.-w.x)*(w.y if dy else 1.-w.y)*(w.z if dz else 1.-w.z)
        return value
    @ti.func
    def _fbm(self,p:ti.template(),seed:ti.i32,octaves:ti.i32)->ti.f32:
        value=0.;total=0.;amplitude=.5;point=p
        for octave in ti.static(range(5)):
            if octave<octaves:value+=self._noise(point,seed+octave*1013)*amplitude;total+=amplitude
            point=point*2.03+ti.Vector([7.1,-3.7,5.3]);amplitude*=.5
        return value/total
    @ti.func
    def _height(self,d:ti.template())->ti.f32:
        warp=ti.Vector([self._fbm(d*3.1+11.,self.seed+17,3),self._fbm(d*3.1-7.,self.seed+31,3),self._fbm(d*3.1+3.,self.seed+47,3)])-.5
        continent=(self._fbm(d*1.65+warp*.7,self.seed,5)-.5)*self.continent_amplitude*2.;ridge_noise=self._fbm(d*8.+warp,self.seed+211,5);ridge=(1.-ti.abs(ridge_noise*2.-1.))**3;land=ti.min(ti.max((continent+700.)/1800.,0.),1.)
        return ti.min(ti.max(continent+ridge*self.mountain_amplitude*land,-5000.),8500.)
    @ti.func
    def _direction(self,face:ti.i32,u:ti.f32,v:ti.f32):
        d=ti.Vector([1.,v,-u])
        if face==1:d=ti.Vector([-1.,v,u])
        elif face==2:d=ti.Vector([u,1.,-v])
        elif face==3:d=ti.Vector([u,-1.,v])
        elif face==4:d=ti.Vector([u,v,1.])
        elif face==5:d=ti.Vector([-u,v,-1.])
        return d.normalized()
    @ti.func
    def _uv_for_vertex(self,index:ti.i32):
        edge=-1;base=index
        if index>=self.surface_vertices:edge=(index-self.surface_vertices)//self.side;base=(index-self.surface_vertices)%self.side
        ix=base%self.side;iy=base//self.side
        if edge==0:ix=base;iy=0
        elif edge==1:ix=self.resolution;iy=base
        elif edge==2:ix=self.resolution-base;iy=self.resolution
        elif edge==3:ix=0;iy=self.resolution-base
        return ix,iy,edge
    @ti.kernel
    def _generate_patch(self,slot:ti.i32,face:ti.i32,level:ti.i32,px:ti.i32,py:ti.i32,radius:ti.f32):
        self.slot_resident[slot]=1;self.slot_face[slot]=face;self.slot_level[slot]=level;self.slot_x[slot]=px;self.slot_y[slot]=py
        scale=ti.cast(1<<level,ti.f32);size=2./scale;u0=-1.+ti.cast(px,ti.f32)*size;v0=-1.+ti.cast(py,ti.f32)*size;center=self._direction(face,u0+size*.5,v0+size*.5)
        for index in range(self.vertices_per_patch):
            ix,iy,edge=self._uv_for_vertex(index);u=u0+size*ti.cast(ix,ti.f32)/self.resolution;v=v0+size*ti.cast(iy,ti.f32)/self.resolution;d=self._direction(face,u,v);h=self._height(d)
            offset=(d-center)*radius+d*h
            if edge>=0:offset-=d*ti.max(5.,radius*size/self.resolution*.05)
            snow=ti.min(ti.max((h-2600.)/1800.,0.),1.);sand=ti.min(ti.max(1.-ti.abs(h)/500.,0.),1.)*(1.-snow);soil=ti.max(1.-snow-sand,0.);weights=ti.Vector([soil,0.,sand,snow]);weights/=ti.max(weights.sum(),1e-8)
            canonical=1<<14;cx=ti.min(ti.max(ti.cast((u*.5+.5)*canonical,ti.i32),0),canonical-1);cy=ti.min(ti.max(ti.cast((v*.5+.5)*canonical,ti.i32),0),canonical-1)
            self.offset[slot,index]=offset;self.normal[slot,index]=d;self.height_m[slot,index]=h;self.material[slot,index]=weights;self.cell[slot,index]=(face<<28)|(cy<<14)|cx

    @ti.kernel
    def _generate_normals(self,slot:ti.i32):
        for index in range(self.surface_vertices):
            x=index%self.side;y=index//self.side;xl=ti.max(x-1,0);xr=ti.min(x+1,self.resolution);yb=ti.max(y-1,0);yt=ti.min(y+1,self.resolution)
            tangent_u=self.offset[slot,y*self.side+xr]-self.offset[slot,y*self.side+xl];tangent_v=self.offset[slot,yt*self.side+x]-self.offset[slot,yb*self.side+x];normal=tangent_u.cross(tangent_v).normalized()
            scale=ti.cast(1<<self.slot_level[slot],ti.f32);size=2./scale;u=-1.+(ti.cast(self.slot_x[slot],ti.f32)+ti.cast(x,ti.f32)/self.resolution)*size;v=-1.+(ti.cast(self.slot_y[slot],ti.f32)+ti.cast(y,ti.f32)/self.resolution)*size;radial=self._direction(self.slot_face[slot],u,v)
            if normal.dot(radial)<0:normal=-normal
            self.normal[slot,index]=normal
        for index in range(self.surface_vertices,self.vertices_per_patch):
            base=(index-self.surface_vertices)%self.side;edge=(index-self.surface_vertices)//self.side;source=base
            if edge==1:source=base*self.side+self.resolution
            elif edge==2:source=self.resolution*self.side+self.resolution-base
            elif edge==3:source=(self.resolution-base)*self.side
            self.normal[slot,index]=self.normal[slot,source]

    def upload_patch(self,slot:int,descriptor:PatchDescriptor)->None:
        k=descriptor.key;self._generate_patch(slot,k.face,k.level,k.x,k.y,float(np.linalg.norm(descriptor.anchor_global)));self._generate_normals(slot)
    def release_patch(self,slot:int|None)->None:
        if slot is not None:self._release(slot)
    @ti.kernel
    def _release(self,slot:ti.i32):self.slot_resident[slot]=0;self.slot_render[slot]=0
    def set_render_patches(self,descriptors:list[PatchDescriptor],slots:dict[PatchKey,int|None])->None:
        self._render_descriptors=tuple(descriptors);self._render_slots={k:int(v) for k,v in slots.items() if v is not None};active=np.zeros(self.max_patches,np.int32);masks=np.zeros(self.max_patches,np.int32)
        for descriptor in descriptors:
            slot=slots.get(descriptor.key)
            if slot is not None:active[slot]=1;masks[slot]=descriptor.skirt_mask
        self._set_render(active,masks);self.patch_count=int(active.sum())
    @ti.kernel
    def _set_render(self,active:ti.types.ndarray(dtype=ti.i32,ndim=1),masks:ti.types.ndarray(dtype=ti.i32,ndim=1)):
        for i in range(self.max_patches):self.slot_render[i]=active[i];self.slot_skirt_mask[i]=masks[i]
    @ti.kernel
    def _set_anchors(self,a:ti.types.ndarray(dtype=ti.f32,ndim=2)):
        for i in range(self.max_patches):self.anchor_relative[i]=ti.Vector([a[i,0],a[i,1],a[i,2]])
    @ti.kernel
    def _clear(self):
        self.tile_overflow[None]=0
        for q in ti.grouped(self.tile_counts):self.tile_counts[q]=0
        for q in ti.grouped(self.depth):self.depth[q]=1e30;self.gbuffer_surface_id[q]=-1;self.gbuffer_surface_cell_id[q]=-1
    @ti.kernel
    def _transform(self,e:ti.types.vector(3,ti.f32),u:ti.types.vector(3,ti.f32),n:ti.types.vector(3,ti.f32),r:ti.types.vector(3,ti.f32),vu:ti.types.vector(3,ti.f32),f:ti.types.vector(3,ti.f32)):
        for slot,index in self.view:
            if self.slot_render[slot]:
                g=self.anchor_relative[slot]+self.offset[slot,index];local=ti.Vector([g.dot(e),g.dot(u),g.dot(n)]);self.view[slot,index]=ti.Vector([local.dot(r),local.dot(vu),local.dot(f)])
    @ti.func
    def _emit(self,s:ti.i32,src:ti.i32,v:ti.template(),n:ti.template(),m:ti.template(),h:ti.template(),c:ti.template(),tf:ti.f32):
        aspect=ti.cast(self.width,ti.f32)/self.height
        for k in ti.static(range(3)):
            p=v[k,:];self.rv[s,k]=p;self.rn[s,k]=n[k,:];self.rm[s,k]=m[k,:];self.rh[s,k]=h[k];self.rc[s,k]=c[k];self.screen[s,k]=ti.Vector([(p.x/(p.z*tf*aspect)*.5+.5)*self.width,(p.y/(p.z*tf)*.5+.5)*self.height,p.z])
        self.source[s]=src;self.valid[s]=1
    @ti.func
    def _cut(self,a:ti.template(),b:ti.template(),an:ti.template(),bn:ti.template(),am:ti.template(),bm:ti.template(),ah:ti.f32,bh:ti.f32,near:ti.f32):
        t=(near-a.z)/(b.z-a.z);return a+(b-a)*t,(an+(bn-an)*t).normalized(),am+(bm-am)*t,ah+(bh-ah)*t
    @ti.kernel
    def _clip(self,near:ti.f32,tf:ti.f32):
        for source_id in range(self.max_patches*self.local_triangle_count):
            slot=source_id//self.local_triangle_count;local_id=source_id%self.local_triangle_count;s=source_id*2;self.valid[s]=0;self.valid[s+1]=0
            skirt_edge=(local_id-self.surface_triangle_count)//(self.resolution*2)
            enabled=local_id<self.surface_triangle_count or (skirt_edge>=0 and (self.slot_skirt_mask[slot]&(1<<skirt_edge))!=0)
            if self.slot_render[slot] and enabled:
                ids=self.local_triangles[local_id];v=ti.Matrix.rows([self.view[slot,ids.x],self.view[slot,ids.y],self.view[slot,ids.z]]);n=ti.Matrix.rows([self.normal[slot,ids.x],self.normal[slot,ids.y],self.normal[slot,ids.z]]);m=ti.Matrix.rows([self.material[slot,ids.x],self.material[slot,ids.y],self.material[slot,ids.z]]);h=ti.Vector([self.height_m[slot,ids.x],self.height_m[slot,ids.y],self.height_m[slot,ids.z]]);c=ti.Vector([self.cell[slot,ids.x],self.cell[slot,ids.y],self.cell[slot,ids.z]]);inside=ti.Vector([v[0,2]>=near,v[1,2]>=near,v[2,2]>=near]);count=ti.cast(inside[0],ti.i32)+ti.cast(inside[1],ti.i32)+ti.cast(inside[2],ti.i32)
                if count==3:self._emit(s,source_id,v,n,m,h,c,tf)
                elif count==1:
                    a=0
                    if inside[1]:a=1
                    elif inside[2]:a=2
                    b=(a+1)%3;d=(a+2)%3;vb,nb,mb,hb=self._cut(v[a,:],v[b,:],n[a,:],n[b,:],m[a,:],m[b,:],h[a],h[b],near);vd,nd,md,hd=self._cut(v[a,:],v[d,:],n[a,:],n[d,:],m[a,:],m[d,:],h[a],h[d],near);self._emit(s,source_id,ti.Matrix.rows([v[a,:],vb,vd]),ti.Matrix.rows([n[a,:],nb,nd]),ti.Matrix.rows([m[a,:],mb,md]),ti.Vector([h[a],hb,hd]),ti.Vector([c[a],c[a],c[a]]),tf)
                elif count==2:
                    d=0
                    if inside[0]:d=2 if inside[1] else 1
                    a=(d+1)%3;b=(d+2)%3;va,na,ma,ha=self._cut(v[a,:],v[d,:],n[a,:],n[d,:],m[a,:],m[d,:],h[a],h[d],near);vb,nb,mb,hb=self._cut(v[b,:],v[d,:],n[b,:],n[d,:],m[b,:],m[d,:],h[b],h[d],near);self._emit(s,source_id,ti.Matrix.rows([v[a,:],v[b,:],vb]),ti.Matrix.rows([n[a,:],n[b,:],nb]),ti.Matrix.rows([m[a,:],m[b,:],mb]),ti.Vector([h[a],h[b],hb]),ti.Vector([c[a],c[b],c[b]]),tf);self._emit(s+1,source_id,ti.Matrix.rows([v[a,:],vb,va]),ti.Matrix.rows([n[a,:],nb,na]),ti.Matrix.rows([m[a,:],mb,ma]),ti.Vector([h[a],hb,ha]),ti.Vector([c[a],c[b],c[a]]),tf)
    @ti.kernel
    def _bin(self):
        for q in self.valid:
            if self.valid[q] and (self.rv[q,1]-self.rv[q,0]).cross(self.rv[q,2]-self.rv[q,0]).dot(-self.rv[q,0]) < 0:
                a,b,c=self.screen[q,0],self.screen[q,1],self.screen[q,2];x0=ti.max(ti.cast(ti.floor(ti.min(a.x,b.x,c.x)),ti.i32),0);x1=ti.min(ti.cast(ti.ceil(ti.max(a.x,b.x,c.x)),ti.i32),self.width-1);y0=ti.max(ti.cast(ti.floor(ti.min(a.y,b.y,c.y)),ti.i32),0);y1=ti.min(ti.cast(ti.ceil(ti.max(a.y,b.y,c.y)),ti.i32),self.height-1)
                if x0<=x1 and y0<=y1:
                    for x,y in ti.ndrange((x0//16,x1//16+1),(y0//16,y1//16+1)):
                        k=ti.atomic_add(self.tile_counts[x,y],1)
                        if k<MAX_TRIANGLES_PER_TILE:self.tile_triangles[x,y,k]=q
                        else:ti.atomic_add(self.tile_overflow[None],1)
    @ti.func
    def _edge(self,a:ti.template(),b:ti.template(),p:ti.template())->ti.f32:return (b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x)
    @ti.func
    def _debug_color(self,h:ti.f32,slot:ti.i32,mode:ti.i32):
        t=ti.min(ti.max((h+5000.)/13500.,0.),1.);color=ti.Vector([.02,.2,.75])*(1.-t)+ti.Vector([.95,.9,.25])*t
        if mode==1:
            hue=ti.cast(self.slot_level[slot]%6,ti.f32)/6.;color=ti.Vector([ti.abs(hue*6.-3.)-1.,2.-ti.abs(hue*6.-2.),2.-ti.abs(hue*6.-4.)]);color=ti.min(ti.max(color,0.),1.)
        elif mode==2:
            value=ti.cast((slot*1103515245+12345)&255,ti.f32)/255.;color=ti.Vector([value,ti.math.fract(value*.73+.21),ti.math.fract(value*.37+.61)])
        return color
    @ti.kernel
    def _raster(self,mode:ti.i32):
        for x,y in self.depth:
            p=ti.Vector([ti.cast(x,ti.f32)+.5,ti.cast(y,ti.f32)+.5]);best=1e30;src=-1;cell=-1;bp=ti.Vector.zero(ti.f32,3);bn=ti.Vector.zero(ti.f32,3);bm=ti.Vector.zero(ti.f32,4);bh=0.
            for k in range(ti.min(self.tile_counts[x//16,y//16],MAX_TRIANGLES_PER_TILE)):
                q=self.tile_triangles[x//16,y//16,k];a,b,c=self.screen[q,0],self.screen[q,1],self.screen[q,2];area=self._edge(a.xy,b.xy,c.xy);sg=1. if area>0 else -1.;e=ti.Vector([self._edge(b.xy,c.xy,p)*sg,self._edge(c.xy,a.xy,p)*sg,self._edge(a.xy,b.xy,p)*sg])
                if ti.abs(area)>1e-8 and e.min()>=-1e-5:
                    l=e/ti.abs(area);z=1./ti.max(l.x/a.z+l.y/b.z+l.z/c.z,1e-20)
                    if z<best:
                        w=ti.Vector([l.x*z/a.z,l.y*z/b.z,l.z*z/c.z]);bp=self.rv[q,0]*w.x+self.rv[q,1]*w.y+self.rv[q,2]*w.z;bn=(self.rn[q,0]*w.x+self.rn[q,1]*w.y+self.rn[q,2]*w.z).normalized();bm=self.rm[q,0]*w.x+self.rm[q,1]*w.y+self.rm[q,2]*w.z;bh=self.rh[q,0]*w.x+self.rh[q,1]*w.y+self.rh[q,2]*w.z;vi=0
                        if w.y>w.x:vi=1
                        if w.z>w[vi]:vi=2
                        cell=self.rc[q,vi];best=z;src=self.source[q]
            if src>=0:
                slot=src//self.local_triangle_count;self.depth[x,y]=best;self.gbuffer_surface_id[x,y]=src;self.gbuffer_surface_cell_id[x,y]=cell;self.gbuffer_position[x,y]=bp;self.gbuffer_normal[x,y]=bn;self.gbuffer_material_weights[x,y]=bm;self.gbuffer_height_m[x,y]=bh;self.gbuffer_albedo[x,y]=self._debug_color(bh,slot,mode)
    @ti.kernel
    def _shade(self,sun_local:ti.types.vector(3,ti.f32),disk:ti.types.vector(3,ti.f32),disk_cos:ti.f32,r:ti.types.vector(3,ti.f32),vu:ti.types.vector(3,ti.f32),f:ti.types.vector(3,ti.f32),tf:ti.f32,ev:ti.f32):
        aspect=ti.cast(self.width,ti.f32)/self.height
        for q in ti.grouped(self.hdr):
            color=ti.Vector([.00015,.0002,.00035])
            if self.gbuffer_surface_id[q]>=0:color=self.gbuffer_albedo[q]
            else:
                sx=((ti.cast(q.x,ti.f32)+.5)/self.width*2.-1.)*aspect;sy=(ti.cast(q.y,ti.f32)+.5)/self.height*2.-1.;ray=(r*sx+vu*sy+f/tf).normalized()
                if ray.dot(sun_local)>=disk_cos:color+=disk
            self.hdr[q]=ti.max(color,0.);self.display[q]=display_transform(color,ev)
    def render(self,planet:PlanetModel,camera:PlanetCamera,lighting:LightingState,surface_albedo:tuple[float,float,float],exposure_ev:float)->None:
        self.planet_radius=planet.radius_m;anchors=np.zeros((self.max_patches,3),np.float32)
        for descriptor in self._render_descriptors:
            slot=self._render_slots.get(descriptor.key)
            if slot is not None:anchors[slot]=(descriptor.anchor_global-camera.position_global).astype(np.float32)
        self._set_anchors(anchors);frame=camera.frame(planet);r,vu,f=camera.view_basis_local();tf=math.tan(math.radians(camera.vertical_fov_degrees)/2);near=max(.1,min(1000.,max(planet.altitude_m(camera.position_global),0.)*.01));sun_local=frame.global_to_local_direction(lighting.sun_direction_global)
        self._clear();self._transform(tuple(frame.east),tuple(frame.up),tuple(frame.north),tuple(r),tuple(vu),tuple(f));self._clip(near,tf);self._bin();self._raster(self.debug_view);self._shade(tuple(sun_local),lighting.sun_disk_radiance,math.cos(math.radians(lighting.sun_angular_radius_degrees)),tuple(r),tuple(vu),tuple(f),tf,exposure_ev)
    @property
    def vertex_count(self)->int:return self.patch_count*self.vertices_per_patch
    @property
    def triangle_count(self)->int:return self.patch_count*self.local_triangle_count
    def benchmark(self,call,repeats:int)->TimingResult:
        s=time.perf_counter();call();ti.sync();jit=time.perf_counter()-s;n=max(repeats,1);s=time.perf_counter()
        for _ in range(n):call()
        ti.sync();avg=(time.perf_counter()-s)/n;return TimingResult(jit,avg,1/max(avg,1e-9))
    def stats(self)->RasterStats:return RasterStats(self.patch_count,self.vertex_count,self.triangle_count,int(self.tile_overflow[None]))
    def display_numpy(self)->np.ndarray:return self.display.to_numpy()
    def hdr_numpy(self)->np.ndarray:return self.hdr.to_numpy()
